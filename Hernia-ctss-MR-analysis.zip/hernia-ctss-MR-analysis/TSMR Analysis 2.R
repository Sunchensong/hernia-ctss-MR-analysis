#1.extract qtl data
system("smr.exe --beqtl-summary Whole_Blood --extract-probe --query 5e-8  --out qtl_data")
a = data.table::fread("qtl_data.txt")
colnames(a) <- c("SNP", "chr", "pos", "effect_allele", "other_allele", "eaf",
                 "id", "Probe_Chr", "Probe_bp", "Phenotype", "Orientation", "beta", "se", "pval")
data.table::fwrite(a, "qtl_data.txt", row.names = F)
#2.run mr
exposure_data = TwoSampleMR::read_exposure_data("qtl_data.txt")
exposure_data = TwoSampleMR::clump_data(exposure_data)
outcome_data = TwoSampleMR::read_outcome_data("finngen_R11_ABDOM_HERNIA_POSTOP.csv", exposure_data$SNP)
harmonise_data <- TwoSampleMR::harmonise_data(exposure_data, outcome_data)
mr_res <- TwoSampleMR::mr(harmonise_data, method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median", "mr_weighted_mode","mr_wald_ratio"))

