#Use smr software to run smr
cmd_exe = "smr.exe"
bfile = "EUR"
gwas_file = "CTSS"
out_file = "res"
thread-num = 24
c <- sprintf("%s --bfile %s --gwas-summary %s --beqtl-summary %s --out %s/smr_whole --thread-num %s",
             cmd_exe, bfile, gwas_file, beqtl_file, out_file, thread_num)
system(c)

